// weather-component.ts
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-weather-component',
  template: `
    <mat-card class="weather">
      <mat-card-header>
        <mat-card-title>Clima Atual</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <p>Temperatura: {{ temperature }}°C</p>
        <p>Condição: {{ condition }}</p>
      </mat-card-content>
    </mat-card>
  `,
  styles: [`
    .weather {
      padding: 16px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
  `]
})
export class WeatherComponent implements OnInit {
  temperature: number;
  condition: string;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.http.get('https://api.openweathermap.org/data/2.5/weather?q=London,UK&units=metric')
      .subscribe((data: any) => {
        this.temperature = data.main.temp;
        this.condition = data.weather[0].description;
      });
  }
}
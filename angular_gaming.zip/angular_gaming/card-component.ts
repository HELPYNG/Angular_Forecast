// card-component.ts
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-card-component',
  template: `
    <mat-card>
      <mat-card-header>
        <mat-card-title>Detalhes do Item</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <p>Id: {{ itemId }}</p>
        <p>Nome: {{ itemName }}</p>
      </mat-card-content>
    </mat-card>
  `,
  styles: [`
    .card {
      background-color: #fff;
      padding: 16px;
      margin: 16px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
  `]
})
export class CardComponent implements OnInit {
  itemId: number;
  itemName: string;

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.itemId = +this.route.snapshot.paramMap.get('id');
    this.itemName = this.route.snapshot.paramMap.get('name');
  }
}
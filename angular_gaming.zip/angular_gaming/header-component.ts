// header-component.ts
import { Component } from '@angular/core';

@Component({
  selector: 'app-header-component',
  template: `
    <mat-toolbar color="primary">
      <mat-toolbar-row>
        <span>Angular Weather App</span>
        <button mat-button routerLink="/forecast">Go to Forecast</button>
      </mat-toolbar-row>
    </mat-toolbar>
  `,
  styles: [`
    .header {
      background-color: #333;
      color: #fff;
      padding: 16px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  `]
})
export class HeaderComponent {}
// forecast-component.ts
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-forecast-component',
  template: `
    <mat-card class="forecast">
      <mat-card-header>
        <mat-card-title>Previsão do Tempo</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <ul>
          <li *ngFor="let day of forecast">
            {{ day.date }}: {{ day.condition }}
          </li>
        </ul>
      </mat-card-content>
    </mat-card>
  `,
  styles: [`
    .forecast {
      padding: 16px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
  `]
})
export class ForecastComponent implements OnInit {
  forecast: any[];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.http.get('https://api.openweathermap.org/data/2.5/forecast?q=London,UK&units=metric')
      .subscribe((data: any) => {
        this.forecast = data.list.slice(0, 5);
      });
  }
}
// home.component.ts
import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  template: `
    <app-header-component></app-header-component>
    <div class="container">
      <app-weather-component></app-weather-component>
      <app-forecast-component></app-forecast-component>
    </div>
  `,
  styles: [`
    .container {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 16px;
    }
  `]
})
export class HomeComponent {}
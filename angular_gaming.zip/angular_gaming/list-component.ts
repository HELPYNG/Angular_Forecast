// list-component.ts
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-component',
  template: `
    <mat-card>
      <mat-card-header>
        <mat-card-title>Lista de Itens</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <ul class="list">
          <li *ngFor="let item of items" (click)="selectItem(item)">
            {{ item.name }}
          </li>
        </ul>
      </mat-card-content>
    </mat-card>
  `,
  styles: [`
    .list {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .list-item {
      padding: 16px;
      border-bottom: 1px solid #ccc;
    }
  `]
})
export class ListComponent implements OnInit {
  items = [
    { id: 1, name: 'Item 1' },
    { id: 2, name: 'Item 2' },
    { id: 3, name: 'Item 3' }
  ];

  constructor(private router: Router) {}

  selectItem(item: any) {
    this.router.navigate(['/card', item.id]);
  }

  ngOnInit(): void {}
}